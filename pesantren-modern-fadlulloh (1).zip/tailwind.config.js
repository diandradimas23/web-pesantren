/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        sage: {
          50: '#f4f7f5',
          100: '#e3ebe5',
          200: '#c5d9c9',
          300: '#9dbfba',
          400: '#84a98c', // Primary Sage
          500: '#52796f',
          600: '#354f52',
          700: '#2f3e46',
        },
        gold: {
          400: '#e0c068',
          500: '#d4af37', // Primary Gold
          600: '#b08d1a',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}