import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import Button from '../components/Button';

const AdminLogin: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (role: 'ADMIN' | 'CUSTOMER_SERVICE') => {
    login(role);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-sage-700 flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-2xl">
        <h2 className="text-2xl font-bold text-center mb-8 text-sage-800">Staff Access</h2>
        <div className="space-y-4">
          <Button onClick={() => handleLogin('ADMIN')} className="w-full justify-center" variant="primary">
            Login as Administrator
          </Button>
          <Button onClick={() => handleLogin('CUSTOMER_SERVICE')} className="w-full justify-center" variant="secondary">
            Login as Customer Service
          </Button>
        </div>
        <p className="mt-6 text-center text-sm text-gray-400">Restricted access for authorized personnel only.</p>
      </div>
    </div>
  );
};

export default AdminLogin;