import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Users } from 'lucide-react';

const Login: React.FC = () => {
  return (
    <div className="min-h-screen bg-sage-50 flex items-center justify-center px-4">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Member Portal */}
        <Link to="/login/member" className="group">
          <div className="bg-white p-8 rounded-xl shadow-md border-2 border-transparent group-hover:border-sage-400 transition-all h-full flex flex-col items-center text-center cursor-pointer">
            <div className="w-20 h-20 bg-sage-100 rounded-full flex items-center justify-center mb-6 text-sage-600 group-hover:bg-sage-600 group-hover:text-white transition-colors">
              <Users size={40} />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Academic Portal</h2>
            <p className="text-gray-500">For Students, Parents, and Teachers.</p>
          </div>
        </Link>

        {/* Admin Portal */}
        <Link to="/login/admin" className="group">
          <div className="bg-white p-8 rounded-xl shadow-md border-2 border-transparent group-hover:border-gold-400 transition-all h-full flex flex-col items-center text-center cursor-pointer">
            <div className="w-20 h-20 bg-gold-100 rounded-full flex items-center justify-center mb-6 text-gold-600 group-hover:bg-gold-500 group-hover:text-white transition-colors">
              <Shield size={40} />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Staff Portal</h2>
            <p className="text-gray-500">For Administrators and CS Officers.</p>
          </div>
        </Link>

      </div>
    </div>
  );
};

export default Login;