import React from 'react';
import StatCard from '../../components/StatCard';
import { Calendar, Users, ClipboardList } from 'lucide-react';

const TeacherDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="My Classes" value="3" icon={Users} />
        <StatCard title="Assignments" value="12" icon={ClipboardList} color="text-blue-500" />
        <StatCard title="Schedule" value="Today" icon={Calendar} color="text-purple-500" />
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="font-bold text-gray-800 mb-4">Recent Activities</h3>
        <p className="text-gray-500">No recent updates.</p>
      </div>
    </div>
  );
};

export default TeacherDashboard;