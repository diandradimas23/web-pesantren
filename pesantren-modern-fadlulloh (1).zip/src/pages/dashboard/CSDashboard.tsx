import React from 'react';
import StatCard from '../../components/StatCard';
import { MessageCircle, UserPlus, Clock } from 'lucide-react';

const CSDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="New Inquiries" value="15" icon={MessageCircle} />
        <StatCard title="Pending Registrations" value="5" icon={UserPlus} color="text-orange-500" />
        <StatCard title="Avg Response Time" value="5m" icon={Clock} color="text-blue-500" />
      </div>
      
       <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="font-bold text-gray-800 mb-4">Incoming Messages</h3>
        <div className="space-y-3">
            {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div>
                        <p className="font-medium text-sm">Potential Guardian {i}</p>
                        <p className="text-xs text-gray-500">Asking about dorm facilities...</p>
                    </div>
                    <span className="text-xs text-sage-600 font-bold">Reply</span>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default CSDashboard;