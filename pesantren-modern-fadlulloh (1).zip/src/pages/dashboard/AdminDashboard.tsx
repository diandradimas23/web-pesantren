import React, { useState, useEffect } from 'react';
import { Users, BookOpen, DollarSign, Smartphone, Wifi, WifiOff, Loader2 } from 'lucide-react';
import StatCard from '../../components/StatCard';
import Button from '../../components/Button';
import GeminiImageEditor from '../../components/GeminiImageEditor';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const AdminDashboard: React.FC = () => {
  const [waStatus, setWaStatus] = useState<'DISCONNECTED' | 'SCANNING' | 'CONNECTED'>('DISCONNECTED');
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'WA' | 'MEDIA'>('OVERVIEW');

  // Simulated chart data
  const data = [
    { name: 'SMP', students: 120 },
    { name: 'MA', students: 85 },
  ];

  const handleConnectWA = () => {
    setWaStatus('SCANNING');
    setTimeout(() => {
      setWaStatus('CONNECTED');
    }, 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex space-x-4 border-b border-gray-200 pb-2">
        <button 
            onClick={() => setActiveTab('OVERVIEW')} 
            className={`pb-2 px-1 ${activeTab === 'OVERVIEW' ? 'border-b-2 border-sage-500 font-bold text-sage-600' : 'text-gray-500'}`}
        >
            Overview
        </button>
        <button 
            onClick={() => setActiveTab('WA')} 
            className={`pb-2 px-1 ${activeTab === 'WA' ? 'border-b-2 border-sage-500 font-bold text-sage-600' : 'text-gray-500'}`}
        >
            WhatsApp Gateway
        </button>
        <button 
            onClick={() => setActiveTab('MEDIA')} 
            className={`pb-2 px-1 ${activeTab === 'MEDIA' ? 'border-b-2 border-sage-500 font-bold text-sage-600' : 'text-gray-500'}`}
        >
            AI Media Studio
        </button>
      </div>

      {activeTab === 'OVERVIEW' && (
        <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Total Students" value="205" icon={Users} />
                <StatCard title="Total Teachers" value="24" icon={BookOpen} color="text-gold-600" />
                <StatCard title="Revenue (Monthly)" value="IDR 45M" icon={DollarSign} color="text-green-600" />
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Registration Analytics</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="students" fill="#84a98c" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </>
      )}

      {activeTab === 'WA' && (
        <div className="bg-white p-6 rounded-lg shadow-sm max-w-2xl mx-auto text-center">
            <h3 className="text-xl font-bold mb-6 flex items-center justify-center gap-2">
                <Smartphone /> WhatsApp Gateway Status
            </h3>
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 mb-6 flex flex-col items-center justify-center min-h-[300px]">
                {waStatus === 'DISCONNECTED' && (
                    <>
                        <WifiOff size={64} className="text-gray-400 mb-4" />
                        <p className="text-gray-500 mb-4">Gateway is disconnected</p>
                        <Button onClick={handleConnectWA}>Connect Device</Button>
                    </>
                )}
                
                {waStatus === 'SCANNING' && (
                    <>
                         <div className="w-48 h-48 bg-gray-900 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                             {/* Simulated QR Scan Line */}
                             <div className="absolute top-0 left-0 w-full h-1 bg-green-500 shadow-[0_0_10px_#22c55e] animate-[scan_2s_infinite_linear]"></div>
                             <span className="text-white text-xs">QR CODE SIMULATION</span>
                         </div>
                         <div className="flex items-center text-sage-600">
                             <Loader2 className="animate-spin mr-2" /> Scanning...
                         </div>
                    </>
                )}

                {waStatus === 'CONNECTED' && (
                    <>
                        <Wifi size={64} className="text-green-500 mb-4" />
                        <p className="text-green-600 font-bold text-lg mb-2">Device Connected</p>
                        <p className="text-gray-500 text-sm mb-4">+62 812-XXXX-XXXX</p>
                        <Button variant="outline" onClick={() => setWaStatus('DISCONNECTED')}>Disconnect</Button>
                    </>
                )}
            </div>
        </div>
      )}

      {activeTab === 'MEDIA' && (
          <GeminiImageEditor />
      )}
    </div>
  );
};

export default AdminDashboard;