import React from 'react';
import StatCard from '../../components/StatCard';
import { BookOpen, Wallet, Activity } from 'lucide-react';

const ParentDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Quran Progress" value="15 Juz" icon={BookOpen} color="text-gold-500" />
        <StatCard title="Bill Status" value="Paid" icon={Wallet} color="text-green-500" />
        <StatCard title="Attendance" value="98%" icon={Activity} color="text-blue-500" />
      </div>

       <div className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-gold-500">
        <h3 className="font-bold text-gray-800 mb-2">Announcement</h3>
        <p className="text-gray-600">Parent teacher meeting scheduled for next Saturday at 09:00 AM.</p>
      </div>
    </div>
  );
};

export default ParentDashboard;