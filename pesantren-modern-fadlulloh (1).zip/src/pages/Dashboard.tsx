import React from 'react';
import { useAuth } from '../AuthContext';
import AdminDashboard from './dashboard/AdminDashboard';
import TeacherDashboard from './dashboard/TeacherDashboard';
import ParentDashboard from './dashboard/ParentDashboard';
import CSDashboard from './dashboard/CSDashboard';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  if (!user) return <div className="p-8 text-center">Please login first.</div>;

  const renderDashboard = () => {
    switch (user.role) {
      case 'ADMIN':
        return <AdminDashboard />;
      case 'TEACHER':
        return <TeacherDashboard />;
      case 'PARENT':
        return <ParentDashboard />;
      case 'CUSTOMER_SERVICE':
        return <CSDashboard />;
      default:
        return <div>Access Denied</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm py-4 px-8">
        <h1 className="text-xl font-bold text-gray-800">
          Welcome back, <span className="text-sage-600">{user.name}</span>
        </h1>
        <p className="text-sm text-gray-500">{user.role}</p>
      </header>
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {renderDashboard()}
      </main>
    </div>
  );
};

export default Dashboard;