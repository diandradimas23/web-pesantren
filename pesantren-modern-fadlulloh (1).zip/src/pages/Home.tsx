import React from 'react';
import { useLanguage } from '../LanguageContext';
import { motion } from 'framer-motion';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import { BookOpen, Award, Users } from 'lucide-react';

const Home: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-sage-700 h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <img 
          src="https://picsum.photos/1920/1080?grayscale" 
          alt="Pesantren Background" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-bold text-white mb-4"
          >
            {t('welcome')} <span className="text-gold-500">Fadlulloh</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-xl text-sage-100 mb-8"
          >
            {t('subtitle')}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex justify-center gap-4"
          >
            <Link to="/admissions">
              <Button variant="secondary" className="px-8 py-3 text-lg font-bold">
                {t('register')}
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-sage-700">{t('program')}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-sage-50 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-sage-200 rounded-full flex items-center justify-center mx-auto mb-4 text-sage-700">
                <BookOpen size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Tahfidz Quran</h3>
              <p className="text-gray-600">Comprehensive memorization program with Sanad certification.</p>
            </div>
            
            <div className="p-6 bg-sage-50 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-sage-200 rounded-full flex items-center justify-center mx-auto mb-4 text-sage-700">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Academic Excellence</h3>
              <p className="text-gray-600">Integrated curriculum (National + Islamic Studies).</p>
            </div>

            <div className="p-6 bg-sage-50 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-sage-200 rounded-full flex items-center justify-center mx-auto mb-4 text-sage-700">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Character Building</h3>
              <p className="text-gray-600">Developing leadership and Akhlaqul Karimah.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;