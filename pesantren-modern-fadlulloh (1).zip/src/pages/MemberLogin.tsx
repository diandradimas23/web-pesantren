import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import Button from '../components/Button';

const MemberLogin: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (role: 'TEACHER' | 'PARENT') => {
    login(role);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-sage-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-lg border border-sage-100">
        <h2 className="text-2xl font-bold text-center mb-8 text-sage-700">Academic Portal</h2>
        <div className="space-y-4">
          <Button onClick={() => handleLogin('TEACHER')} className="w-full justify-center bg-sage-600 hover:bg-sage-700">
            Login as Teacher (Ustadz/Ustadzah)
          </Button>
          <Button onClick={() => handleLogin('PARENT')} className="w-full justify-center bg-gold-500 hover:bg-gold-600 text-white">
            Login as Parent (Wali Santri)
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MemberLogin;