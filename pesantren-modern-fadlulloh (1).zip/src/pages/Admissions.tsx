import React, { useState } from 'react';
import { useLanguage } from '../LanguageContext';
import Button from '../components/Button';
import { AdmissionForm } from '../types';
import { CheckCircle } from 'lucide-react';

const Admissions: React.FC = () => {
  const { t } = useLanguage();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState<AdmissionForm>({
    fullName: '',
    program: 'SMP Tahfidz Indonesia',
    parentName: '',
    phone: '',
    address: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call and save to local storage
    const existing = JSON.parse(localStorage.getItem('pmf_registrations') || '[]');
    localStorage.setItem('pmf_registrations', JSON.stringify([...existing, formData]));
    
    setTimeout(() => {
      setSubmitted(true);
    }, 1000);
  };

  if (submitted) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center bg-gray-50 px-4">
        <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-lg text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-sage-700 mb-2">{t('success')}</h2>
          <p className="text-gray-600 mb-6">Jazakumullah Khairan. We will contact you shortly via WhatsApp.</p>
          <Button onClick={() => setSubmitted(false)} variant="outline">Register Another</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-sage-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-extrabold text-sage-700">{t('admissions')}</h2>
          <p className="mt-2 text-gray-600">Academic Year 2024/2025</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">{t('fullName')}</label>
            <input
              type="text"
              name="fullName"
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-sage-500 focus:ring-sage-500 border p-2"
              value={formData.fullName}
              onChange={handleChange}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Program Selection</label>
            <select
              name="program"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-sage-500 focus:ring-sage-500 border p-2 bg-white"
              value={formData.program}
              onChange={handleChange}
            >
              <option value="SMP Tahfidz Indonesia">{t('smp')}</option>
              <option value="MA Tahfidz Fadlulloh">{t('ma')}</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">{t('parentName')}</label>
              <input
                type="text"
                name="parentName"
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-sage-500 focus:ring-sage-500 border p-2"
                value={formData.parentName}
                onChange={handleChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">{t('phone')} (WhatsApp)</label>
              <input
                type="tel"
                name="phone"
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-sage-500 focus:ring-sage-500 border p-2"
                value={formData.phone}
                onChange={handleChange}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Address</label>
            <textarea
              name="address"
              required
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-sage-500 focus:ring-sage-500 border p-2"
              value={formData.address}
              onChange={handleChange}
            />
          </div>

          <div className="pt-4">
            <Button type="submit" className="w-full justify-center">
              {t('submit')}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Admissions;