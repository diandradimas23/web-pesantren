export type UserRole = 'ADMIN' | 'TEACHER' | 'PARENT' | 'CUSTOMER_SERVICE' | 'GUEST';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
}

export type Language = 'en' | 'id';

export interface AdmissionForm {
  fullName: string;
  program: 'SMP Tahfidz Indonesia' | 'MA Tahfidz Fadlulloh';
  parentName: string;
  phone: string;
  address: string;
}

export interface Stats {
  students: number;
  teachers: number;
  classes: number;
  activities: number;
}