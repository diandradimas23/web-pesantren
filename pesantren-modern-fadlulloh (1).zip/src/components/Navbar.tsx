import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { useLanguage } from '../LanguageContext';
import { Menu, X, LogOut, Globe } from 'lucide-react';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const [isOpen, setIsOpen] = React.useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const toggleLang = () => {
    setLanguage(language === 'en' ? 'id' : 'en');
  };

  return (
    <nav className="bg-sage-700 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 font-bold text-xl tracking-wider text-gold-500">
              PMF FADLULLOH
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link to="/" className="hover:bg-sage-600 px-3 py-2 rounded-md text-sm font-medium">{t('about')}</Link>
              <Link to="/admissions" className="hover:bg-sage-600 px-3 py-2 rounded-md text-sm font-medium">{t('admissions')}</Link>
              {user ? (
                <Link to="/dashboard" className="hover:bg-sage-600 px-3 py-2 rounded-md text-sm font-medium">{t('dashboard')}</Link>
              ) : (
                <Link to="/login" className="bg-gold-500 hover:bg-gold-600 text-sage-700 px-4 py-2 rounded-md text-sm font-bold">{t('portal')}</Link>
              )}
              
              <button onClick={toggleLang} className="flex items-center space-x-1 hover:text-gold-400">
                <Globe size={16} />
                <span className="uppercase">{language}</span>
              </button>

              {user && (
                <button onClick={handleLogout} className="text-red-300 hover:text-white ml-4">
                  <LogOut size={20} />
                </button>
              )}
            </div>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-sage-200 hover:text-white hover:bg-sage-600 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-sage-600">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">{t('about')}</Link>
            <Link to="/admissions" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">{t('admissions')}</Link>
             <button onClick={toggleLang} className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium w-full text-left">
                {language === 'en' ? 'Bahasa Indonesia' : 'English'}
             </button>
            {user ? (
              <>
                 <Link to="/dashboard" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">{t('dashboard')}</Link>
                 <button onClick={handleLogout} className="text-red-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium w-full text-left">{t('logout')}</button>
              </>
            ) : (
              <Link to="/login" className="text-gold-400 hover:text-gold-300 block px-3 py-2 rounded-md text-base font-bold">{t('portal')}</Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;