import React, { useState, useRef } from 'react';
import { editImageWithGemini } from '../services/geminiService';
import Button from './Button';
import { Upload, Wand2, Download } from 'lucide-react';

const GeminiImageEditor: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEdit = async () => {
    if (!image || !prompt) return;

    setIsProcessing(true);
    setError('');
    
    try {
      const editedImage = await editImageWithGemini(image, prompt);
      setImage(editedImage);
    } catch (err) {
      setError('Failed to edit image. Try a simpler prompt or check API key.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-bold text-sage-700 mb-4 flex items-center">
        <Wand2 className="mr-2" size={24} /> 
        AI Media Studio (Powered by Gemini)
      </h2>
      <p className="text-sm text-gray-500 mb-4">
        Upload an image and use natural language to edit it (e.g., "Add a retro filter", "Make it look like a sketch").
      </p>

      <div className="space-y-4">
        {/* Image Preview Area */}
        <div className="border-2 border-dashed border-gray-300 rounded-lg h-64 flex items-center justify-center bg-gray-50 relative overflow-hidden">
          {image ? (
            <img src={image} alt="Preview" className="h-full w-full object-contain" />
          ) : (
            <div className="text-center text-gray-400">
              <Upload className="mx-auto mb-2" />
              <p>No image uploaded</p>
            </div>
          )}
          
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*" 
            className="absolute inset-0 opacity-0 cursor-pointer"
          />
        </div>

        {/* Controls */}
        <div className="flex gap-2">
          <input 
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your edit (e.g., 'Add fireworks in the sky')"
            className="flex-1 border border-gray-300 rounded-md px-3 py-2 focus:ring-sage-500 focus:border-sage-500"
          />
          <Button onClick={handleEdit} isLoading={isProcessing} disabled={!image || !prompt}>
            Generate
          </Button>
        </div>

        {error && <p className="text-red-500 text-sm">{error}</p>}

        {image && (
          <div className="flex justify-end">
            <a href={image} download="edited-image.png" className="text-sage-600 hover:text-sage-800 text-sm flex items-center">
              <Download size={16} className="mr-1"/> Download Result
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default GeminiImageEditor;