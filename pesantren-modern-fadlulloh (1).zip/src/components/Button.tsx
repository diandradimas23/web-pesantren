import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  isLoading?: boolean;
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading, 
  className, 
  disabled,
  ...props 
}) => {
  const baseStyles = "px-4 py-2 rounded-md font-medium transition-colors duration-200 flex items-center justify-center";
  
  const variants = {
    primary: "bg-sage-500 text-white hover:bg-sage-600 active:bg-sage-700 disabled:bg-sage-300",
    secondary: "bg-gold-500 text-sage-700 hover:bg-gold-600 active:bg-gold-700 disabled:bg-gold-300",
    outline: "border-2 border-sage-500 text-sage-500 hover:bg-sage-50"
  };

  return (
    <button
      className={twMerge(baseStyles, variants[variant], className)}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
      ) : null}
      {children}
    </button>
  );
};

export default Button;