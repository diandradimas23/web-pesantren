import React from 'react';
import { useLanguage } from '../LanguageContext';
import { MapPin, Phone, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <footer className="bg-sage-700 text-white pt-8 pb-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-xl font-bold text-gold-500 mb-4">PMF FADLULLOH</h3>
          <p className="text-sage-200 text-sm">{t('footer_desc')}</p>
        </div>
        <div>
          <h4 className="text-lg font-semibold mb-4 text-white">Contact</h4>
          <ul className="space-y-2 text-sage-200 text-sm">
            <li className="flex items-center"><MapPin size={16} className="mr-2"/> Jl. Raya Pesantren No. 99</li>
            <li className="flex items-center"><Phone size={16} className="mr-2"/> +62 812-3456-7890</li>
            <li className="flex items-center"><Mail size={16} className="mr-2"/> info@fadlulloh.com</li>
          </ul>
        </div>
        <div>
          <h4 className="text-lg font-semibold mb-4 text-white">Quick Links</h4>
          <ul className="space-y-2 text-sage-200 text-sm">
             <li><a href="#" className="hover:text-gold-400">Instagram</a></li>
             <li><a href="#" className="hover:text-gold-400">Facebook</a></li>
             <li><a href="#" className="hover:text-gold-400">YouTube</a></li>
          </ul>
        </div>
      </div>
      <div className="mt-8 border-t border-sage-600 pt-4 text-center text-xs text-sage-300">
        &copy; {new Date().getFullYear()} Pesantren Modern Tahfidz Al-Qur'an Fadlulloh. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;