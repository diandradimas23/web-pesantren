import React, { useState, useEffect } from 'react';
import Button from './Button';

const CookieConsent: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('pmf_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('pmf_cookie_consent', 'true');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-sage-700 text-white p-4 shadow-lg z-50 flex flex-col sm:flex-row items-center justify-between">
      <div className="mb-4 sm:mb-0 text-sm">
        We use cookies to ensure you get the best experience on our website.
      </div>
      <Button variant="secondary" onClick={handleAccept} className="text-xs px-4 py-1">
        Accept
      </Button>
    </div>
  );
};

export default CookieConsent;