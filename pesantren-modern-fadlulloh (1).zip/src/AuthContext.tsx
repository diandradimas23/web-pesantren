import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, UserRole } from './types';

interface AuthContextType {
  user: User | null;
  login: (role: UserRole) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('pmf_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (role: UserRole) => {
    const mockUser: User = {
      id: Date.now().toString(),
      name: role === 'ADMIN' ? 'Admin Staff' : role === 'TEACHER' ? 'Ustadz Ahmad' : role === 'PARENT' ? 'Bapak Budi' : 'CS Officer',
      email: `${role.toLowerCase()}@fadlulloh.com`,
      role: role
    };
    setUser(mockUser);
    localStorage.setItem('pmf_user', JSON.stringify(mockUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('pmf_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within an AuthProvider");
  return context;
};