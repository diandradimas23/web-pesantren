import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Language } from './types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    welcome: "Welcome to",
    subtitle: "Building the Quranic Generation with Character",
    admissions: "Admissions",
    portal: "Portal",
    dashboard: "Dashboard",
    logout: "Logout",
    login: "Login",
    register: "Register Now",
    about: "About Us",
    program: "Our Programs",
    contact: "Contact",
    smp: "SMP Tahfidz Indonesia",
    ma: "MA Tahfidz Fadlulloh",
    fullName: "Full Name",
    parentName: "Parent Name",
    phone: "Phone Number",
    submit: "Submit Application",
    success: "Registration Successful!",
    footer_desc: "Educating with heart, guided by the Quran.",
  },
  id: {
    welcome: "Selamat Datang di",
    subtitle: "Membangun Generasi Qur'ani Berkarakter",
    admissions: "PPDB Online",
    portal: "Portal Masuk",
    dashboard: "Dasbor",
    logout: "Keluar",
    login: "Masuk",
    register: "Daftar Sekarang",
    about: "Tentang Kami",
    program: "Program Kami",
    contact: "Kontak",
    smp: "SMP Tahfidz Indonesia",
    ma: "MA Tahfidz Fadlulloh",
    fullName: "Nama Lengkap",
    parentName: "Nama Orang Tua",
    phone: "Nomor Telepon",
    submit: "Kirim Pendaftaran",
    success: "Pendaftaran Berhasil!",
    footer_desc: "Mendidik dengan hati, berpedoman pada Al-Qur'an.",
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('id'); // Default Indonesian

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within a LanguageProvider");
  return context;
};